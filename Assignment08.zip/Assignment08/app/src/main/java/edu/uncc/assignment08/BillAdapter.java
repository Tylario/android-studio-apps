package edu.uncc.assignment08;

import android.content.Context;
import android.icu.text.SimpleDateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;
import java.util.Locale;

public class BillAdapter extends ArrayAdapter<Bill> {

    public BillAdapter(@NonNull Context context, int resource, @NonNull List<Bill> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.bill_item, parent, false);
        }

        // Retrieve the 'Bill' object for the current position
        Bill bill = getItem(position);
        // Further code to bind data to the views goes here

        // Initialize TextViews
        TextView textViewName = convertView.findViewById(R.id.textViewName);
        TextView textViewAmount = convertView.findViewById(R.id.textViewAmount);
        TextView textViewDiscountOut = convertView.findViewById(R.id.textViewDiscountOut);
        TextView textViewTotalBill = convertView.findViewById(R.id.textViewTotalBill);
        TextView textViewBillDate = convertView.findViewById(R.id.textViewBilldate);
        TextView textViewCategoryOut = convertView.findViewById(R.id.textViewCategoryOut);



        textViewName.setText(bill.getName());
        textViewAmount.setText("Bill Amount: " + String.valueOf(bill.getAmount()));  // Display the amount as a plain number
        textViewDiscountOut.setText("Discount: " + String.valueOf(bill.getDiscount()) + "%");  // Display the discount percentage as a plain number
        textViewTotalBill.setText("Total Bill: " + String.valueOf(bill.getAmount() * (1 - bill.getDiscount() / 100)));  // Calculate and display the total amount as a plain number
        textViewBillDate.setText(new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(bill.getBillDate()));  // Formatting the date
        textViewCategoryOut.setText(bill.getCategory());



        // Return the completed view to render on screen
        return convertView;
    }

}
