package edu.uncc.assignment07;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class BookAdapter extends ArrayAdapter<Book> {

    public BookAdapter(@NonNull Context context, @NonNull List<Book> objects) {
        super(context, 0, objects); // Note the '0' here
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_view_books, parent, false);
        }

        Book book = getItem(position);

        TextView textViewBookTitle = convertView.findViewById(R.id.textViewBookTitleListview);
        TextView textViewAuthorName = convertView.findViewById(R.id.textViewAuthorNameListview);
        TextView textViewGenre = convertView.findViewById(R.id.textViewGenreListview);
        TextView textViewYear = convertView.findViewById(R.id.textViewYearListview);

        textViewBookTitle.setText(book.getTitle());
        textViewAuthorName.setText(book.getAuthor());
        textViewGenre.setText(book.getGenre());
        textViewYear.setText(String.valueOf(book.getYear()));

        return convertView; // Return the updated convertView directly
    }
}
