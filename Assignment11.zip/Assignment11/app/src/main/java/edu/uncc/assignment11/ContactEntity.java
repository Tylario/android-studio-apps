package edu.uncc.assignment11;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "contacts")
public class ContactEntity {
    @PrimaryKey(autoGenerate = true)
    public long id;

    @ColumnInfo
    public String name;

    @ColumnInfo
    public String email;

    @ColumnInfo
    public String phoneType;

    @ColumnInfo
    public String groupWork;

    public ContactEntity(String name, String email, String phoneType, String groupWork) {
        this.name = name;
        this.email = email;
        this.phoneType = phoneType;
        this.groupWork = groupWork;
    }
}
