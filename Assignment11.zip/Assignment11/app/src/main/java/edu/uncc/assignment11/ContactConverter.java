package edu.uncc.assignment11.utils;

import edu.uncc.assignment11.ContactEntity;
import edu.uncc.assignment11.models.Contact;

public class ContactConverter {
    public static Contact fromEntity(ContactEntity entity) {
        Contact model = new Contact();
        model.setName(entity.name);
        model.setEmail(entity.email);
        model.setPhone(entity.phoneType); // Update as per your model class
        model.setPhoneType(entity.phoneType);
        model.setGroup(entity.groupWork);
        return model;
    }

    public static ContactEntity toEntity(Contact model) {
        return new ContactEntity(
                model.getName(),
                model.getEmail(),
                model.getPhoneType(),
                model.getGroup()
        );
    }
}
