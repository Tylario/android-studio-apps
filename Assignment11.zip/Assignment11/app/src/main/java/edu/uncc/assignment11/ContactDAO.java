package edu.uncc.assignment11;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ContactDAO {
    @Insert
    void insertAll(ContactEntity... contacts);

    @Delete
    void delete(ContactEntity contact);

    @Query("SELECT * from contacts")
    List<ContactEntity> getAll();

    @Query("SELECT * from contacts WHERE id = :id limit 1")
    ContactEntity findById(long id);

    @Update
    void update(ContactEntity contact);
}
