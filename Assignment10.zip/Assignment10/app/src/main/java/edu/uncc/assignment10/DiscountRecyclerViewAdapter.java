package edu.uncc.assignment10;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DiscountRecyclerViewAdapter extends RecyclerView.Adapter<DiscountRecyclerViewAdapter.DiscountViewHolder> {

    ArrayList<String> discounts;
    DiscountClickListener listener;

    public DiscountRecyclerViewAdapter(ArrayList<String> data, DiscountClickListener mListener) {
        this.discounts = data;
        this.listener = mListener;
    }

    @NonNull
    @Override
    public DiscountViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.discount_row_item, parent, false);
        return new DiscountViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DiscountViewHolder holder, int position) {
        String discount = discounts.get(position);
        holder.textView.setText(discount);
    }

    @Override
    public int getItemCount() {
        return discounts.size();
    }

    public class DiscountViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        public DiscountViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textViewDiscountItem);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onDiscountClick((String) textView.getText());
                }
            });
        }
    }

    public interface DiscountClickListener {
        void onDiscountClick(String discount);
    }
}
