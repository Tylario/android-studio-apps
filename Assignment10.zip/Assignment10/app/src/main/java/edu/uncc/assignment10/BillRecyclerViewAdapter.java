package edu.uncc.assignment10;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

public class BillRecyclerViewAdapter extends RecyclerView.Adapter<BillRecyclerViewAdapter.BillViewHolder> {

    ArrayList<Bill> bills;
    BillClickListener listener;

    public BillRecyclerViewAdapter(ArrayList<Bill> data, BillClickListener mListener) {
        this.bills = data;
        this.listener = mListener;
    }

    @NonNull
    @Override
    public BillViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.bill_row_item, parent, false);
        return new BillViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BillViewHolder holder, int position) {
        Bill bill = bills.get(position);
        holder.textViewBillName.setText(bill.getName());
        holder.textViewBillAmount.setText("Bill Amount: $" + bill.getAmount());
        holder.textViewDiscount.setText("Discount: $" + bill.getDiscount());
        holder.textViewTotalBill.setText("Total Bill: $" + (bill.getAmount() - bill.getDiscount()));
        holder.textViewDate.setText("Date: " + new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(bill.getBillDate()));
        holder.textViewCategory.setText("Category: " + bill.getCategory());

        holder.imageViewDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onDeleteClick(bill);
            }
        });

        holder.imageViewEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onEditClick(bill);
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onBillClick(bill);
            }
        });
    }

    @Override
    public int getItemCount() {
        return bills.size();
    }

    public class BillViewHolder extends RecyclerView.ViewHolder {
        TextView textViewBillName, textViewBillAmount, textViewDiscount, textViewTotalBill, textViewDate, textViewCategory;
        ImageView imageViewDelete, imageViewEdit;

        public BillViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewBillName = itemView.findViewById(R.id.textViewBillName);
            textViewBillAmount = itemView.findViewById(R.id.textViewBillAmount);
            textViewDiscount = itemView.findViewById(R.id.textViewDiscount);
            textViewTotalBill = itemView.findViewById(R.id.textViewTotalBill);
            textViewDate = itemView.findViewById(R.id.textViewDate);
            textViewCategory = itemView.findViewById(R.id.textViewCategory);
            imageViewDelete = itemView.findViewById(R.id.imageViewDelete);
            imageViewEdit = itemView.findViewById(R.id.imageViewEdit);
        }
    }

    public interface BillClickListener {
        void onBillClick(Bill bill);
        void onDeleteClick(Bill bill);
        void onEditClick(Bill bill);
    }
}
