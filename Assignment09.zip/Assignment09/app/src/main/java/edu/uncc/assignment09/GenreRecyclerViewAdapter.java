package edu.uncc.assignment09;

import android.content.Intent;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class GenreRecyclerViewAdapter extends RecyclerView.Adapter<GenreRecyclerViewAdapter.GenreViewHolder> {

    ArrayList<String> genres;
    static GenresFragment.GenresListener listener;

    public GenreRecyclerViewAdapter(ArrayList<String> data, GenresFragment.GenresListener mListener)  {
        this.genres = data;
        this.listener = mListener;
        Log.d("Tag", "GenreRecyclerViewAdapter: " + this.genres); // this outputs a long list of string. looks good
    }

    @NonNull
    @Override
    public GenreViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.genre_row_item, parent, false);

        GenreViewHolder genreViewHolder = new GenreViewHolder(view);

        return genreViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull GenreViewHolder holder, int position) {
        String string = genres.get(position);
        holder.textView.setText(string);
    }

    @Override
    public int getItemCount() {
        Log.d("Tag", "getItemCount: " + this.genres.size());
        return this.genres.size();
    }


    public static class GenreViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        View rootView;
        public GenreViewHolder(@NonNull View itemView) {
            super(itemView);
            rootView = itemView;
            textView = itemView.findViewById(R.id.textViewGenreItem);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.gotoBooksForGenre((String)textView.getText());
                }
            });

        }
    }
}
