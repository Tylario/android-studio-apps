package edu.uncc.assignment09;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BookRecyclerViewAdapter extends RecyclerView.Adapter<BookRecyclerViewAdapter.BookViewHolder> {

    ArrayList<Book> books;
    static BooksFragment.BooksListener listener;

    public BookRecyclerViewAdapter(ArrayList<Book> data, BooksFragment.BooksListener mListener) {
        this.books = data;
        this.listener = mListener;
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.book_row_item, parent, false);
        BookViewHolder bookViewHolder = new BookViewHolder(view);
        return bookViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        Book book = books.get(position);
        holder.textviewTitle.setText(book.getTitle());
        holder.textViewAuthor.setText(book.getAuthor());
        holder.textViewGenre.setText(book.getGenre());
        holder.textViewYear.setText(String.valueOf(book.getYear()));
        holder.rootView.setTag(book); // Set the book as the tag for the root view
    }

    @Override
    public int getItemCount() {
        return this.books.size();
    }

    public static class BookViewHolder extends RecyclerView.ViewHolder {
        TextView textviewTitle, textViewAuthor, textViewGenre, textViewYear;
        View rootView;

        public BookViewHolder(@NonNull View itemView) {
            super(itemView);
            rootView = itemView;
            textviewTitle = itemView.findViewById(R.id.textviewTitle);
            textViewAuthor = itemView.findViewById(R.id.textViewAuthor);
            textViewGenre = itemView.findViewById(R.id.textViewGenre);
            textViewYear = itemView.findViewById(R.id.textViewYear);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.gotoBookDetails((Book) rootView.getTag());
                }
            });
        }
    }
}
